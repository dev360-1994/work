import React, { useState, useEffect } from 'react';
import { connect } from 'react-redux';
import { Card, CardHeader, CardBody, CardTitle, Row, Col, Table, } from "reactstrap";
import { ToastContainer } from 'react-toastify';
import { getRepos } from '../../service/service';
import './dashboard.css';


function DashBoard(props) {
  const { history, acessToekn, allRepos, GetRrops } = props;

  useEffect(() => {
    debugger
    if (acessToekn === null || acessToekn === undefined) {
      history.push('/login');
    } else {
      GetRrops(acessToekn)
    }
  }, []);

  return (
    <div className="content">
      <Row>
        <Col md="12">
          <Card>
            <CardHeader>
              <CardTitle tag="h4">Top Repositories</CardTitle>
            </CardHeader>
            <CardBody>
              <Table>
                <tbody>
                  <tr>
                    <td>Id</td>
                    <td>Name</td>
                    <td>Description</td>
                  </tr>
                  {allRepos && allRepos.length > 0 ?
                    allRepos.map((item, index) => {
                      return (

                        <tr id={index} key={index}>
                          <td>{item.id}</td>
                          <td>{item.name}</td>
                          <td>{item.description}</td>
                        </tr>
                      )
                    }) :
                      <tr>
                        <td></td>
                        <td>No Meetings Found</td>
                        <td></td>
                      </tr>
                  }
                </tbody>
              </Table>
            </CardBody>
          </Card>
        </Col>
      </Row>
      <div>
        <ToastContainer />
      </div>
    </div>
  );
}

const mapStateToProps = state => {
  const acessToekn = state.userDetail.get('accessToken');
  const allRepos = state.userDetail.get('allRepos');
  return {
    acessToekn, allRepos
  }
};

const mapDispatchToProps = dispatch => ({
  GetRrops: (token) => dispatch(getRepos(token)),
});

export default connect(mapStateToProps, mapDispatchToProps)(DashBoard);