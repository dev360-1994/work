import Login from './Login';
import Dashboard from './Dashboard';

export {
    Login,
    Dashboard
}