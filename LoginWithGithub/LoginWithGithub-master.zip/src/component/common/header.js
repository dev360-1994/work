import React from 'react'
import { MenuIcon } from 'react-simple-sidenav';

function Header(props) {
    const { setShowNav, style } = props;
    return (
        <div style={{
            width: '100%', height: 50, backgroundColor: 'rgb(76, 175, 80)', paddingLeft: 15,
            paddingTop: 12, ...style
        }}>
            <MenuIcon onClick={() => setShowNav()} />
        </div>
    )
}

export default Header;
