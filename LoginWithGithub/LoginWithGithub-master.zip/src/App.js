import React from 'react';
import { BrowserRouter as Router, Switch, Route, Redirect } from 'react-router-dom';
import { Provider } from 'react-redux'
import { Login, Dashboard } from './component';
import createBrowserHistory from './history';
import navigationData from './jsons/sidebars.json';
import store from './store/store';



import "bootstrap/dist/css/bootstrap.css";
import "./assets/scss/paper-dashboard.scss?v=1.1.0";
import "./assets/demo/demo.css";
import "perfect-scrollbar/css/perfect-scrollbar.css";
import AdminLayout from './layouts/Admin.jsx'


const history = createBrowserHistory();

function App() {
  return (
    <Provider store={store}>
      <Router history={history}>
        <Switch>
          <Route path='/' exact component={Login} />
          <Route path='/login' exact component={Login} />
          <Route path='/dashboard' render={(props) => <Dashboard navData={navigationData.sideBarValue}
            {...props} />} />
          <Route path="/admin" render={props => <AdminLayout {...props} />} />
          <Redirect to="/admin/dashboard" />

        </Switch>
      </Router>
    </Provider>
  );
}

export default App;
