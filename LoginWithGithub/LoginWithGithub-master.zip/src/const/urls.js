export const USER_DETAILS = 'USER_DETAILS';
export const ACCESS_TOKEN = 'ACCESS_TOKEN';
export const ALL_Repos = 'ALL_Repos';
export const USERS = {
    GET_ALL_USERS: 'GET_ALL_USERS',
}

export const GITHUBCREDENTIALS = {
    client_id: '3c12695db036c05f2356',
    redirect_uri: 'http://localhost:3000/login',
    client_secret: 'e39aa3e8aafb5c9244b773b5dd608fd480425202',
}