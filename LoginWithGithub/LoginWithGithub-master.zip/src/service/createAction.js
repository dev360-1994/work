export default (type, payload = {}, error = false) => ({
    type,
    payload,
    error,
});
