import axios from 'axios'
import { GITHUBCREDENTIALS, ACCESS_TOKEN, ALL_Repos } from '../const/urls'
import toast from '../component/common/toast'
import createAction from './createAction'


const login = (githubcode, history) => dispatch => {
  debugger
  const requestData = {
    client_id: GITHUBCREDENTIALS.client_id,
    redirect_uri: GITHUBCREDENTIALS.redirect_uri,
    client_secret: GITHUBCREDENTIALS.client_secret,
    code: githubcode
  };

  axios.post(`/login/oauth/access_token`, requestData).then(res => {
    debugger
    if (res.status == 200) {
      var arr = res.data.split('&')
      var token = arr[0].split('=')[1]
      dispatch(createAction(ACCESS_TOKEN, token));
      toast("Login Successfully", "success");
      history.push('/admin/dashboard');
    } else {
      toast("Login attempt failed", "error")
    }
  })
}

const getRepos = (token) => dispatch => {
  debugger
  axios.get('/user?access_token=' + token).then(res => {
    debugger
    if (res.status == 200) {
      axios.get(res.data.repos_url).then(result => {
        debugger
        if (result.status == 200) {
          dispatch(createAction(ALL_Repos, result.data));
        } else {
          toast("Error while getting repository", "error")
        }
      })
      //setData(res.data)
    } else {
      toast("Error while getting repository", "error")
    }
  })
}



export {
  login,
  getRepos
};