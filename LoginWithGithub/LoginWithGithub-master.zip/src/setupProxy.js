const proxy = require('http-proxy-middleware')


module.exports = function (app) {
    app.use(proxy("/login/oauth/access_token", {
        target: "https://github.com",
        secure: false,
        changeOrigin: true
    }))
    app.use(proxy("/user", {
        target: "https://api.github.com",
        secure: false,
        changeOrigin: true
    }))
    // app.use(proxy("/repositories", {
    //     target: "https://github-trending-api.now.sh",
    //     secure: false,
    //     changeOrigin: true
    // }))

}