import Login from "../src/component/Login/index"
import Dashboard from "../src/component/Dashboard/index";
var routes = [
  {
    path: "/dashboard",
    name: "Dashboard",
    icon: "nc-icon nc-layout-11",
    component: Dashboard,
    layout: "/admin"
  },
  {
    path: "/login",
    name: "Logout",
    icon: "fa fa-sign-out",
    component: Login,
    layout: ""
  }
];
export default routes;
