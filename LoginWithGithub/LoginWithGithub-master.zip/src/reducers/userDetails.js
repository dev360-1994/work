import { Map } from 'immutable';
import { getfromLocalStorage } from '../utils/common';
import { USER_DETAILS, ACCESS_TOKEN,ALL_Repos } from '../const/urls';
const initialState = new Map({
    userDetail: '',
    jwtToken: ''
})

const userDetails = (state = initialState, action) => {
    debugger
    switch (action.type) {
        case USER_DETAILS:
            return state.set('userDetail', action.payload);
        case ACCESS_TOKEN:
            return state.set('accessToken', action.payload);
        case ALL_Repos:
            return state.set('allRepos', action.payload);
        default:
            return state;
    }
}
export default userDetails;
