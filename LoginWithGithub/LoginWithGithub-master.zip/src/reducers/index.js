import { combineReducers } from 'redux';
import userDetail from './userDetails';
const reducers = combineReducers({
  userDetail: userDetail
});

export default reducers;
