# Android Keystore Credentials

These credentials are used in conjunction with your Android keystore file to sign your app for distribution. 

## Credential Values

- Android keystore password: 50d68e61092f4314b528a9a43bb72d50
- Android key alias: QGFydW5rL3dhdGNoX2dhbWVfZmlsbQ==
- Android key password: d8e9c6c574c049c0ab9ef5287fe65172
      